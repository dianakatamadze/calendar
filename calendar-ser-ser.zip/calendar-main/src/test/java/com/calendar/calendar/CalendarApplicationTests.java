package com.calendar.calendar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalendarApplicationTests {

	@Test
	void contextLoads() {
	}

}
