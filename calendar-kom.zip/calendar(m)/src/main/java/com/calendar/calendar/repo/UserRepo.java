package com.calendar.calendar.repo;

import com.calendar.calendar.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * интерфейс с репозиторием, который дает возможность добавлять, изменять, удалять данные из таблицы user,
 * а также позволяет найти пользователя по столбцу email
 */

@Repository
public interface UserRepo extends JpaRepository<User, Long> {
    /**
     * функция для поиска пользователя в базе данных
     * @param email - email пользователя по которому нужно искать запись
     * @return - возвращает найденную запись
     */
    User findByEmail(String email);
}
