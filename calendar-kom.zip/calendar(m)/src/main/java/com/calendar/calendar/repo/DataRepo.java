package com.calendar.calendar.repo;

import com.calendar.calendar.models.Data;
import org.springframework.data.repository.CrudRepository;

/**
 * интерфейс с репозиторием, который дает возможность добавлять, изменять и удалять данные из таблицы data
 */

public interface DataRepo extends CrudRepository<Data,Long>{
}
