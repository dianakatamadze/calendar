package com.calendar.calendar.services;

import com.calendar.calendar.models.Role;
import com.calendar.calendar.models.User;
import com.calendar.calendar.repo.UserRepo;
import com.calendar.calendar.sec.UserRegistrationDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Collection;
import java.util.stream.Collectors;

/**
 * класс с сервисом, который наследуется от интерфейся UserService
 * и содержит функции регистрации и авторизации пользователей
 */

@Service
public class UserServiceImpl implements UserService{
    /**
     * поле класса, которое имеет тип интерфейса UserRepo
     * используем это поле для сохранения зарегистрировавшегося пользователя в базу данных
     * а также для поиска пользователя в базе данных при авторизации
     */
    private UserRepo userRepo;

    //иницилизируем BCryptPasswordEncoder, чтобы использовать его для расшифровки паролей из базы данных
    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    /**
     * конструктор класса для создание нового объекта с определенным значением
     * @param userRepo - поле для сохранения зарегистрировавшихся
     *                 и поиска авторизованных пользователей
     */
    public UserServiceImpl(UserRepo userRepo) {
        this.userRepo = userRepo;
    }

    /**
     * функция для сохранения регистрирующегося пользователя в таблицу user
     * @param registrationDto - данные пользователя
     * @return - возвращает функцию сохранения пользователя
     */
    @Override
    public User save(UserRegistrationDto registrationDto) {
        User user = new User(registrationDto.getUsername(), registrationDto.getEmail(),
                passwordEncoder.encode(registrationDto.getPassword()), Arrays.asList(new Role("ROLE_USER")));
        return userRepo.save(user);
    }

    /**
     * функция для проверки зарегистрирован ли пользователь
     * @param username - данные, которые ввел пользователь
     * @return - возвращает данные пользователя
     * @throws UsernameNotFoundException - ошибка вызывается, если данные пользователя не найдены
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException{
        User user = userRepo.findByEmail(username);
        if (user == null){
            throw new UsernameNotFoundException("неверный логин или пароль");
        }
        return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), mapRolesToAuthorities(user.getRoles()));
    }

    /**
     * функция для присвоения роли пользователю
     * @param roles - роли
     * @return - возвращает названия ролей
     */
    private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles){
        return roles.stream().map(role -> new SimpleGrantedAuthority(role.getName())).collect(Collectors.toList());
    }
}
