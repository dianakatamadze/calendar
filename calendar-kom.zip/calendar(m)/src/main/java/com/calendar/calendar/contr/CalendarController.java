package com.calendar.calendar.contr;

import com.calendar.calendar.models.Data;
import com.calendar.calendar.repo.DataRepo;
import com.calendar.calendar.services.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * класс для взаимодействия html страниц и функций программы
 */
@Controller
public class CalendarController {
    //иницилизируем DataRepo, DataService, чтобы использовать его встроенные функции
    @Autowired
    private DataRepo dataRepo;
    @Autowired
    private DataService service;

    /**
     * отображаем html страницу calendar-main,
     * где выводятся спортивные события
     * @param model - модель страницы
     * @return - вызываем функцию отображения событий по страницам
     */
    @RequestMapping("/calendar")
    public String calendarMain(Model model) {
        String keyword = null;
        return listByPage(model, 1,"date","asc", keyword);
    }

    /**
     * получаем и добавляем параметры на html странице calendar-main
     * @param model - модель страницы
     * @param currentPage - страница, на которой находится пользователь
     * @param sortField - столбец, по которому сортируются события
     * @param sortDir - критерий сортировки (по возростанию, по убыванию)
     * @param keyword - слово для поиска события
     * @return - возвращаем html страницу со всеми данными
     */
    @GetMapping("/calendar/page/{pageNumber}")
    public String listByPage(Model model,
                             @PathVariable("pageNumber") int currentPage,
                             @Param("sortField") String sortField,
                             @Param("sortDir") String sortDir,
                             @Param("keyword") String keyword){
        Page<Data> page = service.listAll(keyword, currentPage, sortField, sortDir);
        long totalItems = page.getTotalElements();
        int totalPages = page.getTotalPages();
        List<Data> listData = page.getContent();
        model.addAttribute("currentPage", currentPage);
        model.addAttribute("totalItems", totalItems);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("data1", listData);
        model.addAttribute("keyword", keyword);
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDir", sortDir);
        String revesortDir = sortDir.equals("asc") ? "desc" : "asc";
        model.addAttribute("revesortDir", revesortDir);
        return "calendar-main";
    }

    /**
     * отображаем html страницу calendar-add,
     * где пользователь добавляет новое событие
     * @return - возвращаем html страницу calendar-add
     */
    @GetMapping("/calendar/add")
    public String calendarAdd() {
        return "calendar-add";
    }

    /**
     * получаем параметры c html страницы calendar-add,
     * где пользователь добавляет новое событие
     * @param title - название
     * @param date - дата
     * @param location - место проведения
     * @param disc - описание
     * @return - перенаправляем пользователя на html страницу calendar-main
     */
    @PostMapping("/calendar/add")
    public String calendarPostAdd(@RequestParam String title,@RequestParam String date,
                                  @RequestParam String location,
                                  @RequestParam String disc){
        Data data = new Data(title, date, location, disc);
        dataRepo.save(data);
        return "redirect:/calendar";
    }

    /**
     * отображаем html страницу calendar-det, с полными данными по конкретному событию
     * @param id - id события
     * @param model - модель страницы
     * @return - возвращаем html страницу calendar-det
     */
    @GetMapping("/calendar/{id}")
    public String calendarDetails(@PathVariable(value="id") long id, Model model) {
        if(!dataRepo.existsById(id)){
            return "redirect:/calendar";
        }
        Optional<Data> data = dataRepo.findById(id);
        ArrayList<Data> res = new ArrayList<>();
        data.ifPresent(res::add);
        model.addAttribute("data", res);
        return "calendar-det";
    }

    /**
     * отображаем html страницу calendar-edit, где пользователь может редактировать событие
     * @param id - id события
     * @param model - модель страницы
     * @return - возвращаем html страницу calendar-edit
     */
    @GetMapping("/calendar/{id}/edit")
    public String calendarEdit(@PathVariable(value="id") long id, Model model) {
        if(!dataRepo.existsById(id)){
            return "redirect:/calendar";
        }
        Optional<Data> data = dataRepo.findById(id);
        ArrayList<Data> res = new ArrayList<>();
        data.ifPresent(res::add);
        model.addAttribute("data", res);
        return "calendar-edit";
    }

    /**
     * получаем и добавляем параметры на html странице calendar-edit
     * @param id - id события
     * @param title - название
     * @param date - дата
     * @param location - место проведения
     * @param disc - описание
     * @return - перенаправляем пользователя на html страницу calendar-main
     */
    @PostMapping("/calendar/{id}/edit")
    public String calendarPostEdit(@PathVariable(value="id") long id,
                                   @RequestParam String title,
                                   @RequestParam String date,
                                   @RequestParam String location,
                                   @RequestParam String disc){
        Data data = dataRepo.findById(id).orElseThrow(()-> new IllegalStateException("событие не найдено"));
        data.setTitle(title);
        data.setDate(date);
        data.setLocation(location);
        data.setDisc(disc);
        dataRepo.save(data);
        return "redirect:/calendar";
    }

    /**
     * удаляем событие
     * @param id - id события
     * @return - перенаправляем пользователя на html страницу calendar-main
     */
    @PostMapping("/calendar/{id}/del")
    public String calendarPostDel(@PathVariable(value="id") long id){
        Data data = dataRepo.findById(id).orElseThrow(()-> new IllegalStateException("событие не найдено"));
        dataRepo.delete(data);
        return "redirect:/calendar";
    }


}
