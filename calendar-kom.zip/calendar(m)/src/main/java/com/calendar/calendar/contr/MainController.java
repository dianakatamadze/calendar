package com.calendar.calendar.contr;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * класс для взаимодействия html страниц и функций программы
 */
@Controller
public class MainController {
    /**
     * отображение html страницы home, основной страницы
     * @return - возвращаем html страницу home
     */
    @GetMapping("/")
    public String home() {
        return "home";
    }

    /**
     * отображение html страницы about,
     * где написана информация об авторе
     * @return - возвращаем html страницу about
     */
    @GetMapping("/about")
    public String about() {
        return "about";
    }

    /**
     * отображение html страницы login,
     * где авторизируется пользователь
     * @return - возвращаем html страницу login
     */
    @GetMapping("/login")
    public String login(){
        return "login";
    }


}
