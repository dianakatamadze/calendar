package com.calendar.calendar.models;

import javax.persistence.*;

/**
 * класс с таблицей, которая содержит информацию о спорт. событиях
 */

@Entity
@Table(name = "data")

public class Data {
    //поля класса, которые станут столбцами таблицы
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String title;
    private String date;
    private String location;
    private String disc;

    // get и set для полей класса
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDisc() {
        return disc;
    }

    public void setDisc(String disc) {
        this.disc = disc;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    /**
     * конструктор класса для создание нового объекта с определенными значениями
     * @param title - загаловок события
     * @param date - дата события
     * @param location - место проведения события
     * @param disc - описание события
     */
    public Data(String title, String date, String location, String disc) {
        this.title = title;
        this.date = date;
        this.location = location;
        this.disc = disc;
    }

    //конструктор для создания нового объекта класса
    public Data() {
    }
}
