package com.calendar.calendar.models;

public enum Role {
    USER;
}
