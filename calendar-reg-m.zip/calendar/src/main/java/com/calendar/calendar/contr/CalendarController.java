package com.calendar.calendar.contr;

import com.calendar.calendar.models.Data;
import com.calendar.calendar.repo.DataRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Optional;

@Controller
public class CalendarController {

    @Autowired
    private DataRepo dataRepo;

    @GetMapping("/calendar")
    public String calendarMain(Model model) {
        Iterable<Data> data1 = dataRepo.findAll();
        model.addAttribute("data1",data1);
        return "calendar-main";
    }
    @GetMapping("/calendar/add")
    public String calendarAdd(Model model) {
        return "calendar-add";
    }
    @PostMapping("/calendar/add")
    public String calendarPostAdd(@RequestParam String title,@RequestParam String date, Model model){
        Data data = new Data(title, date);
        dataRepo.save(data);
        return "redirect:/calendar";
    }
    @GetMapping("/calendar/{id}")
    public String calendarDetails(@PathVariable(value="id") long id, Model model) {
        if(!dataRepo.existsById(id)){
            return "redirect:/calendar";
        }
        Optional<Data> data = dataRepo.findById(id);
        ArrayList<Data> res = new ArrayList<>();
        data.ifPresent(res::add);
        model.addAttribute("data", res);
        return "calendar-det";
    }
    @GetMapping("/calendar/{id}/edit")
    public String calendarEdit(@PathVariable(value="id") long id, Model model) {
        if(!dataRepo.existsById(id)){
            return "redirect:/calendar";
        }
        Optional<Data> data = dataRepo.findById(id);
        ArrayList<Data> res = new ArrayList<>();
        data.ifPresent(res::add);
        model.addAttribute("data", res);
        return "calendar-edit";
    }
    @PostMapping("/calendar/{id}/edit")
    public String calendarPostEdit(@PathVariable(value="id") long id, @RequestParam String title,@RequestParam String date, Model model){
        Data data = dataRepo.findById(id).orElseThrow(()-> new IllegalStateException("событие не найдено"));
        data.setTitle(title);
        data.setDate(date);
        dataRepo.save(data);
        return "redirect:/calendar";
    }
    @PostMapping("/calendar/{id}/del")
    public String calendarPostDel(@PathVariable(value="id") long id, Model model){
        Data data = dataRepo.findById(id).orElseThrow(()-> new IllegalStateException("событие не найдено"));
        dataRepo.delete(data);
        return "redirect:/calendar";
    }


}
