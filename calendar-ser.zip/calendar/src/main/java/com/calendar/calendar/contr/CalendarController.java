package com.calendar.calendar.contr;

import com.calendar.calendar.models.Data;
import com.calendar.calendar.repo.DataRepo;
import com.calendar.calendar.services.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
public class CalendarController {

    @Autowired
    private DataRepo dataRepo;
    @Autowired
    private DataService service;

    @RequestMapping("/calendar")
    public String calendarMain(Model model) {
        String keyword = null;
        return listByPage(model, 1, keyword);
    }

    @GetMapping("/calendar/page/{pageNumber}")
    public String listByPage(Model model,
                             @PathVariable("pageNumber") int currentPage,
                             @Param("keyword") String keyword){
        Page<Data> page = service.listAll(keyword, currentPage);
        long totalItems = page.getTotalElements();
        int totalPages = page.getTotalPages();
        List<Data> listData = page.getContent();
        model.addAttribute("currentPage", currentPage);
        model.addAttribute("totalItems", totalItems);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("data1", listData);
        model.addAttribute("keyword", keyword);
        return "calendar-main";
    }

    @GetMapping("/calendar/add")
    public String calendarAdd(Model model) {
        return "calendar-add";
    }
    @PostMapping("/calendar/add")
    public String calendarPostAdd(@RequestParam String title,@RequestParam String date, Model model){
        Data data = new Data(title, date);
        dataRepo.save(data);
        return "redirect:/calendar";
    }
    @GetMapping("/calendar/{id}")
    public String calendarDetails(@PathVariable(value="id") long id, Model model) {
        if(!dataRepo.existsById(id)){
            return "redirect:/calendar";
        }
        Optional<Data> data = dataRepo.findById(id);
        ArrayList<Data> res = new ArrayList<>();
        data.ifPresent(res::add);
        model.addAttribute("data", res);
        return "calendar-det";
    }
    @GetMapping("/calendar/{id}/edit")
    public String calendarEdit(@PathVariable(value="id") long id, Model model) {
        if(!dataRepo.existsById(id)){
            return "redirect:/calendar";
        }
        Optional<Data> data = dataRepo.findById(id);
        ArrayList<Data> res = new ArrayList<>();
        data.ifPresent(res::add);
        model.addAttribute("data", res);
        return "calendar-edit";
    }
    @PostMapping("/calendar/{id}/edit")
    public String calendarPostEdit(@PathVariable(value="id") long id, @RequestParam String title,@RequestParam String date, Model model){
        Data data = dataRepo.findById(id).orElseThrow(()-> new IllegalStateException("событие не найдено"));
        data.setTitle(title);
        data.setDate(date);
        dataRepo.save(data);
        return "redirect:/calendar";
    }
    @PostMapping("/calendar/{id}/del")
    public String calendarPostDel(@PathVariable(value="id") long id, Model model){
        Data data = dataRepo.findById(id).orElseThrow(()-> new IllegalStateException("событие не найдено"));
        dataRepo.delete(data);
        return "redirect:/calendar";
    }


}
