package com.calendar.calendar.repo;

import com.calendar.calendar.models.Data;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;


public interface DataPagRepo extends PagingAndSortingRepository<Data, Long> {
    @Query("SELECT d FROM Data d WHERE " + "CONCAT(d.title, d.date)" + "  LIKE %?1% ")
    public Page <Data> findAll(String keyword, Pageable pageable);

}
