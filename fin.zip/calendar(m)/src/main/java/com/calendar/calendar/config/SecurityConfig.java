package com.calendar.calendar.config;

import com.calendar.calendar.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
    //иницилизируем интерфейс UserService, чтобы использовать его встроенные функции
    @Autowired
    private UserService userService;
    //функция для расшифровки пароля
    @Bean
    public BCryptPasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }

    //функция для сохранения пользователя
    @Bean
    public DaoAuthenticationProvider authenticationProvider(){
        DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
        auth.setPasswordEncoder(passwordEncoder());
        auth.setUserDetailsService(userService);
        return auth;
    }

    //функция для определения пользователя
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception{
        auth.authenticationProvider(authenticationProvider());
    }

    //функция для разгранечения уровня доступа
    @Override
    protected void configure(HttpSecurity http) throws Exception{
        http
                    .authorizeRequests()
                    // html страницы, которые доступны всем пользователям
                    .antMatchers("/", "/registration","/about").permitAll()
                    .anyRequest().authenticated()
                .and()
                    .formLogin()
                    //html страница отображающая авторизацию
                    .loginPage("/login")
                    .permitAll()
                .and()
                    //возможность выйти после авторизации
                    .logout()
                    .invalidateHttpSession(true)
                    .clearAuthentication(true)
                    .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                    .logoutSuccessUrl("/login?logout")
                    .permitAll();
    }
}
