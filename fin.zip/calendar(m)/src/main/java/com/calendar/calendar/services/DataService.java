package com.calendar.calendar.services;

import com.calendar.calendar.models.Data;
import com.calendar.calendar.repo.DataPagRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

/**
 * класс с сервисом, который хранит функции отображения данных из таблицы data
 * а также сортировки записей
 * и поиска записи по заданному слову
 */

@Service
public class DataService {
    //иницилизируем интерфейс DataPagRepo, чтобы использовать его встроенные функции
    @Autowired
    private DataPagRepo repo;


    /**
     * функция, чтобы отображать записи из таблицы data
     * также функция ищет нужные записи по заданному слову
     * также функция сортирует записи из таблицы по заданному критерию
     * @param keyword - слово для поиска записи в таблице data
     * @param pageNumber - страница, на которой находится пользователь
     * @param sortField - столбец по которому сортируются записи
     * @param sortDir - критерий сортировка (по возростанию или по убыванию)
     * @return - возвращает нужные записи в определенной последовательности
     */
    public Page<Data> listAll(String keyword, int pageNumber, String sortField, String sortDir){
        Sort sort = Sort.by(sortField);
        sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
        Pageable pageable = PageRequest.of(pageNumber-1,2,sort);
        if (keyword != null){
            return repo.findAll(keyword, pageable);
        }
        return repo.findAll(pageable);
    }

}
