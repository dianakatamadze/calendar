package com.calendar.calendar.models;

import javax.persistence.*;

/**
 * класс с таблицей, которая содержит роли для пользователей
 */

@Entity
@Table(name = "role")

public class Role {
    //поля класса, которые станут столбцами таблицы
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    /**
     * конструктор класса для создание нового объекта с определенным значением
     * @param name - название роли
     */
    public Role(String name) {

        this.name = name;
    }
    //конструктор для создания нового объекта класса
    public Role(){
        
    }
    // get и set для полей класса
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}