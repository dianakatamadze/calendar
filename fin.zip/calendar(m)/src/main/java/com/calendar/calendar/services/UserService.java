package com.calendar.calendar.services;

import com.calendar.calendar.models.User;
import com.calendar.calendar.sec.UserRegistrationDto;
import org.springframework.security.core.userdetails.UserDetailsService;

/**
 * интерфейс с сервисом, который дает возможность сохранить регистрирующегося пользователя в базу данных
 */

public interface UserService extends UserDetailsService {
    /**
     * функция для сохранения регистрирующегося пользователя в таблицу user
     * @param registrationDto - данные пользователя
     * @return - возвращает функцию сохранения пользователя
     */
    User save(UserRegistrationDto registrationDto);
}
