package com.calendar.calendar.contr;

import com.calendar.calendar.sec.UserRegistrationDto;
import com.calendar.calendar.services.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * класс для взаимодействия html страниц и функций программы
 */
@Controller
@RequestMapping("/registration")
public class UserRegistrationController {
    /**
     * поле класса, которое имеет тип интерфейса UserService
     * используем поле для сохранения данных клиента в таблицу user
     */
    private UserService userService;

    /**
     * конструктор класса для создание нового объекта с определенным значением
     * @param userService - поле с функциями интерфейса UserService
     */
    public UserRegistrationController(UserService userService) {

        this.userService = userService;
    }

    // модель для регистрации пользователя
    @ModelAttribute("user")
    public UserRegistrationDto userRegistrationDto(){
        return new UserRegistrationDto();
    }

    /**
     * отображение html страницы registration,
     * где пользователь регистрируется
     * @return - возвращаем html страницу registration
     */
    @GetMapping
    public String showRegistrationForm(){
        return "registration";
    }

    /**
     * получаем параметры c html страницы registration,
     * где пользователь ввел свои данные
     * @param registrationDto - данные пользователя
     * @return - сообщаем пользователю, что регистрация прошла
     */
    @PostMapping
    public String registerUserAccount(@ModelAttribute("user")UserRegistrationDto registrationDto){
        userService.save(registrationDto);
        return "redirect:/registration?success";
    }
}
