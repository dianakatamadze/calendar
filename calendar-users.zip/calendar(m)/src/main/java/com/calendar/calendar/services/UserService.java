package com.calendar.calendar.services;

import com.calendar.calendar.models.User;
import com.calendar.calendar.sec.UserRegistrationDto;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
    User save(UserRegistrationDto registrationDto);
}
